/*! `dart` grammar compiled for Highlight.js 11.12.0 */
  (function(){
    var hljsGrammar = (function () {
  'use strict';

  /*
  Language: Dart
  Requires: markdown.js
  Author: Maxim Dikun <dikmax@gmail.com>
  Description: Dart a modern, object-oriented language developed by Google. For more information see https://www.dartlang.org/
  Website: https://dart.dev
  Category: scripting
  */

  /** @type LanguageFn */
  function dart(hljs) {

    const regex = hljs.regex;

    const SUBST = {
      className: 'subst',
      variants: [ { begin: '\\$[A-Za-z0-9_]+' } ]
    };

    const BRACED_SUBST = {
      className: 'subst',
      variants: [
        {
          begin: /\$\{/,
          end: /\}/
        }
      ],
      keywords: 'true false null this is new super'
    };

    const NUMBER = {
      className: 'number',
      relevance: 0,
      variants: [
        { match: /\b[0-9][0-9_]*(\.[0-9][0-9_]*)?([eE][+-]?[0-9][0-9_]*)?\b/ },
        { match: /\b0[xX][0-9A-Fa-f][0-9A-Fa-f_]*\b/ }
      ]
    };

    const STRING = {
      className: 'string',
      variants: [
        {
          begin: 'r\'\'\'',
          end: '\'\'\''
        },
        {
          begin: 'r"""',
          end: '"""'
        },
        {
          begin: 'r\'',
          end: '\'',
          illegal: '\\n'
        },
        {
          begin: 'r"',
          end: '"',
          illegal: '\\n'
        },
        {
          begin: '\'\'\'',
          end: '\'\'\'',
          contains: [
            hljs.BACKSLASH_ESCAPE,
            SUBST,
            BRACED_SUBST
          ]
        },
        {
          begin: '"""',
          end: '"""',
          contains: [
            hljs.BACKSLASH_ESCAPE,
            SUBST,
            BRACED_SUBST
          ]
        },
        {
          begin: '\'',
          end: '\'',
          illegal: '\\n',
          contains: [
            hljs.BACKSLASH_ESCAPE,
            SUBST,
            BRACED_SUBST
          ]
        },
        {
          begin: '"',
          end: '"',
          illegal: '\\n',
          contains: [
            hljs.BACKSLASH_ESCAPE,
            SUBST,
            BRACED_SUBST
          ]
        }
      ]
    };
    BRACED_SUBST.contains = [
      NUMBER,
      STRING
    ];

    const BUILT_IN_TYPES = [
      // dart:core
      'Comparable',
      'DateTime',
      'Duration',
      'Function',
      'Iterable',
      'Iterator',
      'List',
      'Map',
      'Match',
      'Object',
      'Pattern',
      'RegExp',
      'Set',
      'Stopwatch',
      'String',
      'StringBuffer',
      'StringSink',
      'Symbol',
      'Type',
      'Uri',
      'bool',
      'double',
      'int',
      'num',
      // dart:html
      'Element',
      'ElementList'
    ];
    const NULLABLE_BUILT_IN_TYPES = BUILT_IN_TYPES.map((e) => `${e}?`);

    const BASIC_KEYWORDS = [
      "abstract",
      "as",
      "assert",
      "async",
      "await",
      "base",
      "break",
      "case",
      "catch",
      "class",
      "const",
      "continue",
      "covariant",
      "default",
      "deferred",
      "do",
      "dynamic",
      "else",
      "enum",
      "export",
      "extends",
      "extension",
      "external",
      "factory",
      "false",
      "final",
      "finally",
      "for",
      "Function",
      "get",
      "hide",
      "if",
      "implements",
      "import",
      "in",
      "interface",
      "is",
      "late",
      "library",
      "mixin",
      "new",
      "null",
      "on",
      "operator",
      "part",
      "required",
      "rethrow",
      "return",
      "sealed",
      "set",
      "show",
      "static",
      "super",
      "switch",
      "sync",
      "this",
      "throw",
      "true",
      "try",
      "typedef",
      "var",
      "void",
      "when",
      "while",
      "with",
      "yield"
    ];

    const KEYWORDS = {
      keyword: BASIC_KEYWORDS,
      built_in:
        BUILT_IN_TYPES
          .concat(NULLABLE_BUILT_IN_TYPES)
          .concat([
            // dart:core
            'Never',
            'Null',
            'dynamic',
            'print',
            // dart:html
            'document',
            'querySelector',
            'querySelectorAll',
            'window'
          ]),
      $pattern: /[A-Za-z][A-Za-z0-9_]*\??/
    };

    const CLASS_NAME_RE = regex.concat(
      /\b_?/,
      regex.either(
        /(?:[A-Z]+[a-z0-9]+)+/,
        /(?:[A-Z]+[a-z0-9]+)+[A-Z]+/
      ),
      /(?![A-Za-z0-9_])/
    );

    const CLASS_REFERENCE = {
      match: CLASS_NAME_RE,
      scope: "title.class"
    };

    const FUNCTION_REFERENCE = {
      match: /\b(?!(?:assert|catch|for|if|switch|while)\b)[a-z_][A-Za-z0-9_]*(?=\()/,
      scope: "title.function"
    };

    return {
      name: 'Dart',
      keywords: KEYWORDS,
      contains: [
        STRING,
        hljs.COMMENT(
          /\/\*\*(?!\/)/,
          /\*\//,
          {
            subLanguage: 'markdown',
            relevance: 0
          }
        ),
        hljs.COMMENT(
          /\/{3,} ?/,
          /$/, { contains: [
            {
              subLanguage: 'markdown',
              begin: '.',
              end: '$',
              relevance: 0
            }
          ] }
        ),
        hljs.C_LINE_COMMENT_MODE,
        hljs.C_BLOCK_COMMENT_MODE,
        {
          className: 'class',
          beginKeywords: 'class interface',
          end: /\{/,
          excludeEnd: true,
          contains: [
            { beginKeywords: 'extends implements' },
            hljs.UNDERSCORE_TITLE_MODE
          ]
        },
        CLASS_REFERENCE,
        FUNCTION_REFERENCE,
        NUMBER,
        {
          className: 'meta',
          begin: '@[A-Za-z]+'
        }
      ]
    };
  }

  return dart;

})();

    hljs.registerLanguage('dart', hljsGrammar);
  })();